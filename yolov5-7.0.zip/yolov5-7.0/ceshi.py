#sup_loss = (torch.pow(teacher_feature - student_feature, 2) * mask_batch_no).sum() / norms

import torch
teacher_feature = torch.rand(8,4,4,5,2)
student_feature = torch.rand(6,4,4,5,2)
mask_batch_no = torch.rand(6,1,4,5,2)
#d = (torch.pow(teacher_feature - student_feature, 2) * mask_batch_no).sum() / 3
#print(d)
#print(c.shape[0])
aa = teacher_feature.shape[0]
bb = student_feature.shape[0]
cc = mask_batch_no.shape[0]
if aa == bb and bb == cc:
    f = (torch.pow(teacher_feature - student_feature, 2) * mask_batch_no).sum() / 3
    print('a')
else:
    teacher_feature = teacher_feature.mean(0).unsqueeze(0)
    f = (torch.pow(teacher_feature - student_feature, 2) * mask_batch_no).sum() / 3
    print('b')



list = [1,2,3,4]

print(list[0:3])
list = list[0:3]
print(list)