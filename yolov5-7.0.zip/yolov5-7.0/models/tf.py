import matplotlib.pyplot as plt
import numpy as np
'''
#x_axis_data = ['Goose','Cow','Duck','Horse','Pig','Sheep','Chicken'] #x
x_axis_data = ['Yolov5-N','Yolov5-S','Yolov5-M','Yolov5-L','Yolov5-X'] #x
y_axis_data = [11190,11520,13133,14295,13612,17344,35108] #y
plt.ylim(5000,50000)
plt.plot(x_axis_data, y_axis_data, 'b*--', alpha=0.5, linewidth=1, label='image + class')#'bo-'表示蓝色实线，数据点实心原点标注
## plot中参数的含义分别是横轴值，纵轴值，线的形状（'s'方块,'o'实心圆点，'*'五角星   ...，颜色，透明度,线的宽度和标签 ，

plt.legend()  #显示上面的label
plt.xlabel('class') #x_label
plt.ylabel('class+image')#y_label
 
#plt.ylim(-1,1)#仅设置y轴坐标范围
plt.show()

'''
x_axis_data = ['Yolov5-N','Yolov5-S','Yolov5-M','Yolov5-L','Yolov5-X'] #x
y_axis_data = [11190,11520,13133,14295,13612,17344,35108] #y
import random
import matplotlib.pyplot as plt
from pylab import mpl
# 设置显示中文字体
mpl.rcParams["font.sans-serif"] = ["SimHei"]
# 有时候，字体更改后，会导致坐标轴中的部分字符无法正常显示，此时需要更改axes.unicode_minus参数
# 设置正常显示符号
mpl.rcParams["axes.unicode_minus"] = False
# 0. 准备x,y坐标的数据
#x = range(60)
x = ['Yolov5-N','Yolov5-S','Yolov5-M','Yolov5-L','Yolov5-X']
p = [75.8,81.4,84.3,84.3,82.4]   # 列表生成式
r = [74.3,74.9,75.2,77,77.4]
mp = [76.6,80.7,81.1,82.1,82.3]

# 1. 创建画布
plt.figure(figsize=(20, 8), dpi=100)

# 2. 绘制折线图
plt.plot(x, p, label='P')
plt.plot(x, r, color='r', linestyle='--', label='R')
plt.plot(x, mp, color='b', linestyle='--', label='mP')
# 显示图例
plt.legend(loc='best')

# 2.1 添加x,y轴刻度
# 设置x,y轴刻度
x_ticks_label = x
y_ticks = range(70,90)

# 修改x,y轴坐标刻度显示
plt.xticks(x_ticks_label)  # 坐标刻度不可以直接通过字符串进行修改
plt.yticks(y_ticks[::5])

# 2.2 添加网格显示
plt.grid(True, linestyle='--', alpha=0.5)  # 开启网格，虚线，透明度0.5

# 2.3 添加描述信息
plt.xlabel("模型")
plt.ylabel("性能")
plt.title("yolov5+初始数据集尝试", fontsize=20)

# 2.4 图像保存
# 保存图片到指定路径
# 在引号中放到是保存的路径
# plt.savefig("./test.png")

# 3. 显示图像
plt.show()

'''

