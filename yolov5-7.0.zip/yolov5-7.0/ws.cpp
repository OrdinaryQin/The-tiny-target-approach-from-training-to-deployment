#include <iostream>
using namespace std;
struct ListNode{
    int val;
    ListNode* next;
    ListNode(int x):val(x). next(nullptr){}
};
int main(){
    int num;
    cin >> num;
    ListNode* head = new ListNode(num);
    ListNode* pre = head;
    while(cin>>get() != '\n') {
        cin >> num;
        pre->next= ;
        pre = pre->next;
    }
    while(head){

    }

}
struct TreeNode
{
    int
};

