#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (c) 2019 luozw, Inc. All Rights Reserved

Authors: luozhiwang(luozw1994@outlook.com)
Date: 2020/9/7
"""
import os
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch_pruning as tp
import copy
import matplotlib.pyplot as plt
from models.yolo import Model


def load_model(cfg="G:/wsq/yolov5-7.0/models/yolov5n.yaml", weights="G:/wsq/yolov5-7.0/models/yolov5n.pt"):
    restor_num = 0
    ommit_num = 0
    model = Model(cfg).to(device)
    ckpt = torch.load(weights, map_location=device)  # load checkpoint
    dic = {}
    for k, v in ckpt['model'].float().state_dict().items():
        if k in model.state_dict() and model.state_dict()[k].shape == v.shape:
            dic[k] = v
            restor_num += 1
        else:
            ommit_num += 1

    print("Build model from", cfg)
    print("Resotre weight from", weights)
    print("Restore %d vars, ommit %d vars" % (restor_num, ommit_num))

    ckpt['model'] = dic
    model.load_state_dict(ckpt['model'], strict=False)
    del ckpt

    model.float()
    model.model[-1].export = True
    return model
def compute_distillation_feature_loss(s_f, t_f, model, loss):
  #  h = model.hyp  # hyperparameters
    ft = torch.cuda.FloatTensor if s_f[0].is_cuda else torch.Tensor
    dl_1, dl_2, dl_3 = ft([0]), ft([0]), ft([0])

    loss_func1 = nn.MSELoss(reduction="mean")
    loss_func2 = nn.MSELoss(reduction="mean")
    loss_func3 = nn.MSELoss(reduction="mean")

    dl_1 += loss_func1(s_f[0], t_f[0])
    dl_2 += loss_func2(s_f[1], t_f[1])
    dl_3 += loss_func3(s_f[2], t_f[2])

    bs = s_f[0].shape[0]
    dl_1 *= 1 / 20
    dl_2 *= 1 / 20
    dl_3 *= 1 / 20
    loss += (dl_1 + dl_2 + dl_3) * bs
    return loss



from utils.general import LOGGER, check_version, check_yaml, make_divisible, print_args
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg', default="G:/wsq/yolov5-7.0/models/yolov5n.yaml", type=str, help='*.cfg path')
    parser.add_argument('--weights', default="G:/wsq/yolov5-7.0/models/yolov5n.pt", type=str, help='*.data path')
    parser.add_argument('--save-dir', default="./weight", type=str, help='*.data path')
    parser.add_argument('-p', '--prob', default=0.5, type=float, help='pruning prob')
    parser.add_argument('-t', '--thres', default=0.01, type=float, help='pruning thres')
    opt = parser.parse_args()

    opt.cfg = check_yaml(opt.cfg)
    cfg = opt.cfg
    weights = opt.weights
    save_dir = opt.save_dir

    device = torch.device('cpu')
    model = load_model(cfg, weights)    




    activation = {}
    def get_activation(name):
        print('bbbbbbb')
        def hook(model, inputs, outputs):
            print('aaaaaa')
            activation[name] = outputs
        return hook

    
    hooks = []
    # S-model
    hooks.append(model.model._modules["6"].register_forward_hook(get_activation("s_f1")))
    hooks.append(model.model._modules["13"].register_forward_hook(get_activation("s_f2")))
    hooks.append(model.model._modules["17"].register_forward_hook(get_activation("s_f3")))
        # T-model
     #   hooks.append(t_model.model._modules["4"].register_forward_hook(get_activation("t_f1")))
      #  hooks.append(t_model.model._modules["6"].register_forward_hook(get_activation("t_f2")))
      #  hooks.append(t_model.model._modules["10"].register_forward_hook(get_activation("t_f3")))
      #  return hooks
    # feature convert

    x = example_inputs = torch.zeros((1, 3, 640, 640), dtype=torch.float32).to()
    out1,out2,out3= model(x)
    print(out1.shape)

    from models.common import Converter
    c1 = 128
    c2 = 256
    c3 = 512

    S_Converter_1 = Converter(128, c1, act=True)
    S_Converter_2 = Converter(128, c2, act=True)
    S_Converter_3 = Converter(64, c3, act=True)
    S_Converter_1.to(device)
    S_Converter_2.to(device)
    S_Converter_3.to(device)
    S_Converter_1.train()
    S_Converter_2.train()
    S_Converter_3.train()

    T_Converter_1 = nn.ReLU6()
    T_Converter_2 = nn.ReLU6()
    T_Converter_3 = nn.ReLU6()
    # T_Converter_1 = Converter(c1, 32, act=True)
    # T_Converter_2 = Converter(c2, 96, act=True)
    # T_Converter_3 = Converter(c3, 320, act=True)
    T_Converter_1.to(device)
    T_Converter_2.to(device)
    T_Converter_3.to(device)
    T_Converter_1.train()
    T_Converter_2.train()
    T_Converter_3.train()

   # hooks = get_hooks()
#    print(hooks)
    #print(activation)
    s_f1 = S_Converter_1(activation["s_f1"])
    s_f2 = S_Converter_2(activation["s_f2"])
    s_f3 = S_Converter_3(activation["s_f3"])
    print(s_f3.shape)
    s_f = [s_f1, s_f2, s_f3]

    loss = compute_distillation_feature_loss(s_f, s_f, model, 1)

    print(loss)

