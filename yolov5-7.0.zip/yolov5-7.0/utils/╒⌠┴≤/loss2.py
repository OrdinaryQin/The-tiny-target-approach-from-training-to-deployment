
import torch
import torch.nn as nn
def compute_distillation_feature_loss(s_f, t_f, model, loss):
    h = model.hyp  # hyperparameters
    ft = torch.cuda.FloatTensor if s_f[0].is_cuda else torch.Tensor
    dl_1, dl_2, dl_3 = ft([0]), ft([0]), ft([0])

    loss_func1 = nn.MSELoss(reduction="mean")
    loss_func2 = nn.MSELoss(reduction="mean")
    loss_func3 = nn.MSELoss(reduction="mean")

    dl_1 += loss_func1(s_f[0], t_f[0])
    dl_2 += loss_func2(s_f[1], t_f[1])
    dl_3 += loss_func3(s_f[2], t_f[2])

    bs = s_f[0].shape[0]
    dl_1 *= h['dist'] / 20
    dl_2 *= h['dist'] / 20
    dl_3 *= h['dist'] / 20
    loss += (dl_1 + dl_2 + dl_3) * bs
    return loss
