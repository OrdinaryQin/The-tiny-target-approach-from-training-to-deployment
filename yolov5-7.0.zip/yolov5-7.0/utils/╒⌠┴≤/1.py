import torch
import torch.nn as nn
G/wsq/master
model的正常输出t_p，p,一是直接用原来的，二是根本代码进行同时训练学习。
def compute_distillation_output_loss(p, t_p, model, d_weight=1):
    t_ft = torch.cuda.FloatTensor if t_p[0].is_cuda else torch.Tensor
    t_lcls, t_lbox, t_lobj = t_ft([0]), t_ft([0]), t_ft([0])
    h = model.hyp  # hyperparameters
    red = 'mean'  # Loss reduction (sum or mean)
    if red != "mean":
        raise NotImplementedError("reduction must be mean in distillation mode!")

    DboxLoss = nn.MSELoss(reduction="none")
    DclsLoss = nn.MSELoss(reduction="none")
    DobjLoss = nn.MSELoss(reduction="none")
    # per output
    for i, pi in enumerate(p):  # layer index, layer predictions
        t_pi = t_p[i]
        t_obj_scale = t_pi[..., 4].sigmoid()

        # BBox
        b_obj_scale = t_obj_scale.unsqueeze(-1).repeat(1, 1, 1, 1, 4)
        t_lbox += torch.mean(DboxLoss(pi[..., :4], t_pi[..., :4]) * b_obj_scale)

        # Class
        if model.nc > 1:  # cls loss (only if multiple classes)
            c_obj_scale = t_obj_scale.unsqueeze(-1).repeat(1, 1, 1, 1, model.nc)
            # t_lcls += torch.mean(c_obj_scale * (pi[..., 5:] - t_pi[..., 5:]) ** 2)
            t_lcls += torch.mean(DclsLoss(pi[..., 5:], t_pi[..., 5:]) * c_obj_scale)

        # t_lobj += torch.mean(t_obj_scale * (pi[..., 4] - t_pi[..., 4]) ** 2)
        t_lobj += torch.mean(DobjLoss(pi[..., 4], t_pi[..., 4]) * t_obj_scale)
    t_lbox *= h['box']
    t_lobj *= h['obj']
    t_lcls *= h['cls']
    # bs = p[0].shape[0]  # batch size
    loss = (t_lobj + t_lbox + t_lcls) * d_weight
    return loss

#d_outputs_loss = compute_distillation_output_loss(pred, t_pred, model, d_weight=10)
if __name__ == "__main__":
    feature = torch.rand(3,64,3, 80, 80,23)
    print(feature.shape)
    d_outputs_loss = compute_distillation_output_loss(feature, feature, d_weight=10)
    '''
    #anchors = torch.tensor()
    anchors = torch.rand(3,2)
    gt_boxes = torch.rand(131,6)
    feature = torch.rand(64,3, 80, 80,23)
    imp = torch.rand(640,640)
    print(gt_boxes[:, 0].shape)
    #boxes = gt_boxes[gt_boxes[:, 0] == 1]
    a = getMask(64,gt_boxes,imp.shape,feature,anchors,15,device= 'cpu')
    #print((np.array(a)).shape)
    b = compute_mask_loss(a, feature, feature, 0.5)
    '''
