import torch
import torch.nn as nn

t_model = torch.load(r'G:/wsq/yolov5-7.0/models/yolov5n.pt', map_location=torch.device('cpu'))
if t_model.get("model", None) is not None:
    t_model = t_model["model"]
t_model.to('cpu')
t_model.float()
t_model.train()



activation = {}
def get_activation(name):
    def hook(model, inputs, outputs):
        activation[name] = outputs
    return hook

def get_hooks():
    hooks = []
    # S-model
    hooks.append(model.model._modules["6"].register_forward_hook(get_activation("s_f1")))
    hooks.append(model.model._modules["13"].register_forward_hook(get_activation("s_f2")))
    hooks.append(model.model._modules["17"].register_forward_hook(get_activation("s_f3")))
    # T-model
    hooks.append(t_model.model._modules["4"].register_forward_hook(get_activation("t_f1")))
    hooks.append(t_model.model._modules["6"].register_forward_hook(get_activation("t_f2")))
    hooks.append(t_model.model._modules["10"].register_forward_hook(get_activation("t_f3")))
    return hooks
# feature convert
from models.common import Converter
c1 = 128
c2 = 256
c3 = 512
if opt.type == "dfmvocs_l":
    c1 = 256
    c2 = 512
    c3 = 1024
S_Converter_1 = Converter(32, c1, act=True)
S_Converter_2 = Converter(96, c2, act=True)
S_Converter_3 = Converter(320, c3, act=True)
S_Converter_1.to(device)
S_Converter_2.to(device)
S_Converter_3.to(device)
S_Converter_1.train()
S_Converter_2.train()
S_Converter_3.train()

T_Converter_1 = nn.ReLU6()
T_Converter_2 = nn.ReLU6()
T_Converter_3 = nn.ReLU6()
# T_Converter_1 = Converter(c1, 32, act=True)
# T_Converter_2 = Converter(c2, 96, act=True)
# T_Converter_3 = Converter(c3, 320, act=True)
T_Converter_1.to(device)
T_Converter_2.to(device)
T_Converter_3.to(device)
T_Converter_1.train()
T_Converter_2.train()
T_Converter_3.train()
#d_outputs_loss = compute_distillation_output_loss(pred, t_pred, model, d_weight=10)
if __name__ == "__main__":
    feature = torch.rand(3,64,3, 80, 80,23)
    print(feature.shape)

    '''
    #anchors = torch.tensor()
    anchors = torch.rand(3,2)
    gt_boxes = torch.rand(131,6)
    feature = torch.rand(64,3, 80, 80,23)
    imp = torch.rand(640,640)
    print(gt_boxes[:, 0].shape)
    #boxes = gt_boxes[gt_boxes[:, 0] == 1]
    a = getMask(64,gt_boxes,imp.shape,feature,anchors,15,device= 'cpu')
    #print((np.array(a)).shape)
    b = compute_mask_loss(a, feature, feature, 0.5)
    '''
