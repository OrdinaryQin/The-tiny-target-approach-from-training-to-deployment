

    if opt.dist:
        print("load t-model from", opt.t_weights)
        t_model = torch.load(opt.t_weights, map_location=torch.device('cpu'))
        if t_model.get("model", None) is not None:
            t_model = t_model["model"]
        t_model.to(device)
        t_model.float()
        t_model.train()

        if opt.d_feature:
            activation = {}
            def get_activation(name):
                def hook(model, inputs, outputs):
                    activation[name] = outputs
                return hook

            def get_hooks():
                hooks = []
                # S-model
                hooks.append(model.model._modules["6"].register_forward_hook(get_activation("s_f1")))
                hooks.append(model.model._modules["13"].register_forward_hook(get_activation("s_f2")))
                hooks.append(model.model._modules["17"].register_forward_hook(get_activation("s_f3")))
                # T-model
                hooks.append(t_model.model._modules["4"].register_forward_hook(get_activation("t_f1")))
                hooks.append(t_model.model._modules["6"].register_forward_hook(get_activation("t_f2")))
                hooks.append(t_model.model._modules["10"].register_forward_hook(get_activation("t_f3")))
                return hooks
            # feature convert
            from models.common import Converter
            c1 = 128
            c2 = 256
            c3 = 512
            if opt.type == "dfmvocs_l":
                c1 = 256
                c2 = 512
                c3 = 1024
            S_Converter_1 = Converter(32, c1, act=True)
            S_Converter_2 = Converter(96, c2, act=True)
            S_Converter_3 = Converter(320, c3, act=True)
            S_Converter_1.to(device)
            S_Converter_2.to(device)
            S_Converter_3.to(device)
            S_Converter_1.train()
            S_Converter_2.train()
            S_Converter_3.train()

            T_Converter_1 = nn.ReLU6()
            T_Converter_2 = nn.ReLU6()
            T_Converter_3 = nn.ReLU6()
            # T_Converter_1 = Converter(c1, 32, act=True)
            # T_Converter_2 = Converter(c2, 96, act=True)
            # T_Converter_3 = Converter(c3, 320, act=True)
            T_Converter_1.to(device)
            T_Converter_2.to(device)
            T_Converter_3.to(device)
            T_Converter_1.train()
            T_Converter_2.train()
            T_Converter_3.train()


    for epoch in range(start_epoch, epochs):  # epoch ------------------------------------------------------------------
        if opt.dist and opt.d_feature:
            hooks = get_hooks()

            pred = model(imgs)
            if opt.dist:
                if opt.d_online:
                    t_pred = t_model(imgs)
                    for p in t_pred:
                        p = p.detach()
                else:
                    with torch.no_grad():
                        t_pred = t_model(imgs)
                if opt.d_feature:
                    s_f1 = S_Converter_1(activation["s_f1"])
                    s_f2 = S_Converter_2(activation["s_f2"])
                    s_f3 = S_Converter_3(activation["s_f3"])
                    s_f = [s_f1, s_f2, s_f3]
                    s_f = (activation["s_f1"], activation["s_f2"], activation["s_f3"])
                    t_f1 = T_Converter_1(activation["t_f1"])
                    t_f2 = T_Converter_2(activation["t_f2"])
                    t_f3 = T_Converter_3(activation["t_f3"])
                    t_f = [t_f1, t_f2, t_f3]

loss = compute_distillation_feature_loss(s_f, t_f, model, loss)


        if opt.dist and opt.d_feature:
            for hook in hooks:
                hook.remove()